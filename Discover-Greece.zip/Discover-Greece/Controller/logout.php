<?php

session_start();
session_unset();
session_destroy();

include "/home/UAD/1704807/public_html/index.php";

?>
