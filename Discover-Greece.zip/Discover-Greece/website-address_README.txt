https://mayar.abertay.ac.uk/~1704807/index.php

client system has to be authenticated with the Abertay University firewall.